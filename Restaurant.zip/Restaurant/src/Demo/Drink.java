package Demo;

public class Drink extends Item{

	public Drink(String ininame, double iniprice, String inisize, String initype,int ininumber) {
		super(ininame, iniprice, inisize, initype,ininumber);
	}
	
	
	@Override
	public int getNumber() {
		// TODO �Զ����ɵķ������
		return super.getNumber();
	}


	@Override
	public void setNumber(int number) {
		// TODO �Զ����ɵķ������
		super.setNumber(number);
	}


	public String getName() {
		return super.getName();
	}

	public void setName(String name) {
		super.setName(name);
	}

	public double getPrice() {
		return super.getPrice();
	}

	public void setPrice(double price) {
		super.setPrice(price);
	}

	public String getSize() {
		return super.getSize();
	}
	public void setSize(String size) {
		super.setSize(size);
	}

	public String getprint() {
		String s = super.getSize()+"ml";
		return s;
	}
	public String getType() {
		return "drink";
	}
	public void setType(String initype) {
		super.setType(initype);
	}
	
}
