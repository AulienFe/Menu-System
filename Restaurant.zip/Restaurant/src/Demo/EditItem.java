package Demo;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class EditItem extends JFrame {

	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditItem frame = new EditItem(null,0.0,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditItem(String ininame,double iniprice,String inisize) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 640);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u540D\u79F0");
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(38, 78, 59, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u4EF7\u683C");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(38, 179, 59, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u89C4\u683C");
		lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(38, 286, 59, 31);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u7C7B\u522B");
		lblNewLabel_3.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(38, 394, 59, 31);
		contentPane.add(lblNewLabel_3);
		
		String s =String.valueOf(iniprice);
		textField_1 = new JTextField(s);
		textField_1.setColumns(10);
		textField_1.setBounds(148, 179, 265, 31);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField(inisize);
		textField_2.setColumns(10);
		textField_2.setBounds(148, 286, 265, 31);
		contentPane.add(textField_2);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\u83DC\u54C1");
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setSelected(true);
		rdbtnNewRadioButton.setFont(new Font("����", Font.PLAIN, 20));
		rdbtnNewRadioButton.setBounds(148, 400, 121, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\u996E\u54C1");
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setFont(new Font("����", Font.PLAIN, 20));
		rdbtnNewRadioButton_1.setBounds(271, 400, 121, 23);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JButton btnNewButton = new JButton("\u53D6\u6D88");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				quit();
			}
		});//ȡ��
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBounds(297, 521, 116, 31);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u786E\u5B9A");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = ininame;
				String prices = textField_1.getText();
				String size = textField_2.getText();
				String type = "";
				if(rdbtnNewRadioButton.isSelected()==true) {
					type = "food";
					ArrayList<Item>list = new ArrayList<>();
					ArrayList<Item>listr = new ArrayList<>();
					Food food = new Food(name,Double.parseDouble(prices),size,type,0);
					try {
						list = ItemToFile.ReadItem("E:/Item.csv");
						for(Item item:list) {
							while(item.getName().equals(name)) {
								listr.add(item);
								break;
							}
						}
						list.removeAll(listr);
						list.add(food);
						ItemToFile.ItemToFile1(list, "E:/Item.csv");
					} catch (IOException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
				}else if(rdbtnNewRadioButton_1.isSelected()==true) {
					type = "drink";
					ArrayList<Item>list = new ArrayList<>();
					ArrayList<Item>listr = new ArrayList<>();
					Drink drink = new Drink(name,Double.parseDouble(prices),size,type,0);
					try {
						list = ItemToFile.ReadItem("E:/Item.csv");
						for(Item item:list) {
							while(item.getName().equals(name)) {
								listr.add(item);
								break;
							}
						}
						list.removeAll(listr);
						list.add(drink);
						ItemToFile.ItemToFile1(list, "E:/Item.csv");
					} catch (IOException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
				}
				JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
				quit();
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_1.setBounds(38, 521, 116, 31);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel(ininame);
		lblNewLabel_4.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(148, 78, 121, 25);
		contentPane.add(lblNewLabel_4);
	}
	public void quit() {
		this.dispose();
	}
}
