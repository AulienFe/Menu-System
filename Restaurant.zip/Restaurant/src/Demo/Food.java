package Demo;

public class Food extends Item{

	
	public Food(String ininame, double iniprice, String inisize, String initype,int ininumber) {
		super(ininame, iniprice, inisize, initype,ininumber);
	}

	
	@Override
	public int getNumber() {
		// TODO �Զ����ɵķ������
		return super.getNumber();
	}


	@Override
	public void setNumber(int number) {
		// TODO �Զ����ɵķ������
		super.setNumber(number);
	}


	public String getName() {
		
		return super.getName();
	}

	
	public void setName(String name) {
		
		super.setName(name);
	}

	
	public double getPrice() {
		
		return super.getPrice();
	}

	
	public void setPrice(double price) {
		
		super.setPrice(price);
	}

	
	public void setSize(String size) {
		
		super.setSize(size);
	}
	public String getSize() {
		return super.getSize();
	}
	
	public String getprint() {
		String s = super.getSize()+"g";
		return s;
	}
	public String getType() {
		return "food";
	}

	public void setType(String initype) {
		super.setType(initype);
	}
	
/*	public void Food(String ininame,double iniprice,String inisize,String initype) {
		super.getName();
		super.getPrice();
		super.getSize();
		
	}*/
}
