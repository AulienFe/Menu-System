package Demo;

public abstract class Item {
	private String name;
	private double price;
	private String size;
	private String type;
	private int number;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public abstract String getprint() ;
	public abstract String getType();
	public void setType(String initype) {
		type = initype;
	}
	
	public Item (String ininame,double iniprice,String inisize,String initype,int ininumber) {
		name = ininame;
		price = iniprice;
		size = inisize;
		type = initype;
		number = ininumber;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
}
