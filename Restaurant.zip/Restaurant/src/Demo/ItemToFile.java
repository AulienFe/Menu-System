package Demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;



public class ItemToFile {
	public static void ItemToFile(ArrayList<Item> ItemList, String fileName1) throws IOException {
		File file1 = new File(fileName1);
		FileWriter fileWriter1 = new FileWriter(file1,true);
		String content="";
		for(Item item : ItemList){
			String line =item.getName()+","+item.getPrice()+","+item.getSize()+","+item.getType()+","+item.getNumber()+"\n";
			content += line;
		}
		fileWriter1.write(content);
		fileWriter1.close();
	}
	
	public static ArrayList<Item> ReadItem(String fileName) throws IOException {
		File file = new File(fileName);
		BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		ArrayList<Item> listout = new ArrayList<>();
		
		String line = bufferedReader.readLine();
		
		while(line!=null) {
			String[] array = line.split(",");
			if(array[3].equals("food") ) {
				Food food = new Food(array[0],Double.parseDouble(array[1]),array[2],array[3],Integer.parseInt(array[4]));
				listout.add(food);
			}else if(array[3].equals("drink")) {
				Drink drink = new Drink(array[0],Double.parseDouble(array[1]),array[2],array[3],Integer.parseInt(array[4]));
				listout.add(drink);
			}
			/*Item item = new Item(array[0],array[1],array[2]);*/
			
			line = bufferedReader.readLine();
		}
		
		return listout;
		
	}

	
	public static void ItemToFile1(ArrayList<Item> ItemList, String fileName1) throws IOException {
		File file1 = new File(fileName1);
		FileWriter fileWriter1 = new FileWriter(file1);
		String content="";
		for(Item item : ItemList){
			String line = item.getName()+","+item.getPrice()+","+item.getSize()+","+item.getType()+","+item.getNumber()+"\n";
			content += line;
		}
		fileWriter1.write(content);
		fileWriter1.close();
	}
	
	
}
