package Demo;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Menu extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public Menu() throws IOException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1155, 720);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		showtable();
		
		JButton btnNewButton = new JButton("\u6DFB\u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddItem adi = new AddItem();
				adi.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton.setBounds(10, 133, 162, 44);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u5220\u9664");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = table.getSelectedRow();
				i = table.convertRowIndexToModel(i);
				String name =(String) table.getModel().getValueAt(i, 0);
				double price =(double) table.getModel().getValueAt(i, 1);
				String size =(String) table.getModel().getValueAt(i, 2);
				String type =(String) table.getModel().getValueAt(i, 3);
				int number =(int) table.getModel().getValueAt(i, 4);
				
				ArrayList<Item>list = new ArrayList<>();
				ArrayList<Item>listr = new ArrayList<>();
				try {
					list = ItemToFile.ReadItem("E:/Item.csv");
					for(Item item:list) {
						while(item.getName().equals(name)) {
							listr.add(item);
							break;
						}
					}
					list.removeAll(listr);
					ItemToFile.ItemToFile1(list, "E:/Item.csv");
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});//ɾ��
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_1.setBounds(236, 133, 151, 44);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u4FEE\u6539");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i1 = table.getSelectedRow();
				i1 = table.convertRowIndexToModel(i1);
				String name1 =(String) table.getModel().getValueAt(i1, 0);
				double price1 =(double) table.getModel().getValueAt(i1, 1);
				String size1 =(String) table.getModel().getValueAt(i1, 2);
				size1 = size1.trim();
				String size2 = "";
				for(int i =0;i<size1.length();i++) {
					if(size1.charAt(i)>=48 && size1.charAt(i)<=57) {
						size2 += size1.charAt(i);
					}
				}
				EditItem edi = new EditItem(name1,price1,size2);
				edi.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_2.setBounds(10, 59, 162, 44);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("\u70B9\u9910");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = table.getSelectedRow();
				i = table.convertRowIndexToModel(i);
				String name =(String) table.getModel().getValueAt(i, 0);
				ArrayList<Item> list = new ArrayList<>();
				try {
					list = ItemToFile.ReadItem( "E:/Item.csv");
					for(Item item:list) {
						while(name.equals(item.getName())) {
							int a = item.getNumber();
							a++;
							item.setNumber(a);
							break;
						}
					}
					ItemToFile.ItemToFile1(list,"E:/Item.csv");
					refresh re = new refresh();
					re.refresh();
					quit();
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_3.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_3.setBounds(742, 133, 151, 44);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\u7ED3\u7B97");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s =" ���� "+"   "+"����*����"+"   "+" �ܼ� "+"\n";
				double sum = 0.0;
				ArrayList<Item> list = new ArrayList<>();
				try {
					list = ItemToFile.ReadItem( "E:/Item.csv");
					for(Item item:list) {						
						if(item.getNumber()!=0) {
							sum = sum + item.getPrice()*item.getNumber();
							s = s + item.getName()+"    "+item.getPrice()+"*"+item.getNumber()+"    "+item.getPrice()*item.getNumber()+"\n";
						}else if(item.getNumber()==0) {
							
						}
					}
					s = s + "�ܼƣ�  "+sum+"Ԫ";
					JOptionPane.showMessageDialog(null, s);
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_4.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_4.setBounds(970, 133, 146, 44);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("\u5237\u65B0");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				refresh re = new refresh();
				try {
					re.refresh();
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				quit();
			}
		});
		btnNewButton_5.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_5.setBounds(970, 62, 146, 38);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("\u79FB\u9664\u70B9\u9910");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int i = table.getSelectedRow();
				i = table.convertRowIndexToModel(i);
				String name =(String) table.getModel().getValueAt(i, 0);
				ArrayList<Item> list = new ArrayList<>();
				try {
					list = ItemToFile.ReadItem( "E:/Item.csv");
					for(Item item:list) {
						while(name.equals(item.getName())) {
							int a = item.getNumber();
							if(a!=0) {
								a--;
								item.setNumber(a);
							}else if(a == 0) {
								item.setNumber(a);
							}
							break;
						}
					}
					ItemToFile.ItemToFile1(list,"E:/Item.csv");
					refresh re = new refresh();
					re.refresh();
					quit();
				} catch (IOException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_6.setFont(new Font("����", Font.PLAIN, 20));
		btnNewButton_6.setBounds(742, 59, 151, 44);
		contentPane.add(btnNewButton_6);
	}
	
	public void quit() {
		this.dispose();
	}
	
	public void showtable() throws IOException {
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 203, 1121, 470);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.getTableHeader().setReorderingAllowed(false);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setFont(new Font("����", Font.PLAIN, 16));
		
		/*table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5546\u54C1\u540D", "\u4EF7\u683C", "\u89C4\u683C", "\u7C7B\u578B", "\u6570\u91CF"
			}
		));*/
		Object[][] context = new Object[][]{
		};
		Object[] title = new String[] {
				"\u5546\u54C1\u540D", "\u4EF7\u683C", "\u89C4\u683C", "\u7C7B\u578B", "\u6570\u91CF"
			};
		DefaultTableModel dtm =new  DefaultTableModel(context,title);
		
		ArrayList<Item> itemlist= new ArrayList<>();
		itemlist = ItemToFile.ReadItem("E:/Item.csv");
		for(Item item:itemlist) {
			String name = item.getName();
			double price = item.getPrice();
			String size = item.getprint();
			String type = item.getType();
			int number = item.getNumber();
			Object[] data = new Object[] {name,price,size,type,number};
			dtm.addRow(data);
			table.setModel(dtm);
		}
		
		scrollPane.setViewportView(table);

	}

}
