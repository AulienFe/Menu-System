package Demo;

import java.io.IOException;

public class refresh {
	public void refresh() throws IOException {
		Menu menu = new Menu();
		menu.setVisible(true);
	}
	
}
